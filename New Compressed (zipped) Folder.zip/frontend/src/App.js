// src/App.js
import React from 'react';
import ScanForm from './components/ScanForm';
import './App.css';

function App() {
    return (
        <div className="App">
            <ScanForm />
        </div>
    );
}

export default App;
